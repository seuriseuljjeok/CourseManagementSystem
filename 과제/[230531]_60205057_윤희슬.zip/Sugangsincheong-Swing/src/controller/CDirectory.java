package controller;
import Ex.ValueObject.VDirectory;
import model.MDirectory;

import java.io.IOException;
import java.util.Vector;

public class CDirectory {
    private MDirectory eDirectory;
    private VDirectory vDirectory;

    public CDirectory() {
        this.eDirectory = new MDirectory();
        this.vDirectory = new VDirectory();
    }

    public Vector<VDirectory> getDirectories(String fileName) throws IOException {
        return this.eDirectory.getDirectories(fileName);
    }

    public String getFileName() {
        return this.vDirectory.getFileName();
    }
}