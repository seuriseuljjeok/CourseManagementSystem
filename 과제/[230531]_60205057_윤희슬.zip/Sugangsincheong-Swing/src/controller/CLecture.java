package controller;

import Ex.ValueObject.VLecture;
import model.MLecture;

import java.util.Vector;

public class CLecture {
    private MLecture eLecture;
    public CLecture(){
        this.eLecture = new MLecture();
    }
    public Vector<VLecture> getLectures(String fileName){
        return this.eLecture.getDirectories(fileName);
    }}

