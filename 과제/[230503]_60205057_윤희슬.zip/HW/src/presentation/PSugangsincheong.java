package presentation;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import model.MData;
import valueObject.VData;
import valueObject.VUserInfo;

public class PSugangsincheong {
//	private VUserInfo vUserInfo;
	MData mData;

	private class Index{
		//직접적으로 아래의 변수들을 사용하면 안됨 (ex .code)
		//getter, setter를 이용하여 캡슐화해서 사용해야 함.
		private int code;
		private String name;
		private String fileName;
		private String credit;
		private String time;
		private String professor;
		
		public int getCode() {return code;}
		public void setCode(int code) {this.code = code;}
		public String getName() {return name;}
		public void setName(String name) {this.name = name;}
		public String getFileName() {return fileName;}
		public void setFileName(String fileName) {this.fileName = fileName;}
		public String getCredit() {return credit;}
		public void setCredit(String credit) {this.credit = credit;}
		public String getTime() {return time;}
		public void setTime(String time) {this.time = time;}
		public String getProfessor() {return professor;}
		public void setProfessor(String professor) {this.professor = professor;}
		

		public String findFileName(int code) {return this.fileName;}		

		public boolean checkCode(int code) {
			if(this.code == code)return true;
			else return false;}
	}
	
	private String nextIndex(String message, String fileName, Scanner keyboard) {
		
		try {
			System.out.println(message);
			Scanner file = new Scanner(new File(fileName));
			Vector<Index> indexVector = new Vector<Index>();
			while(file.hasNext()) {
				Index index = new Index();
				index.setCode(file.nextInt());
				index.setName(file.next());
				index.setFileName(file.next());
				indexVector.add(index);
				System.out.println(index.getCode() + " " +index.getName());
			}
			file.close();
			String command = keyboard.next();
			int selection = Integer.parseInt(command);
			
			String selectedFileName = findFileName(indexVector, selection);
			return selectedFileName;
		} catch (FileNotFoundException e) {e.printStackTrace();}
		return null;		
	}
	
	private String printLectureList(String message, String fileName) {
		
		try {
			System.out.println(message);
			Scanner file = new Scanner(new File(fileName));
			Vector<Index> indexVector = new Vector<Index>();
			while(file.hasNext()) {
				Index index = new Index();
				index.setCode(file.nextInt());
				index.setName(file.next());
				index.setProfessor(file.next());
				index.setCredit(file.next());
				index.setTime(file.next());

				indexVector.add(index);
				System.out.println(index.getCode() + " " +index.getName()+ " " +index.getProfessor()+ " " +index.getCredit() + " " +index.getTime());
			}
			file.close();
			
		} catch (FileNotFoundException e) {e.printStackTrace();}
		return null;		
	}
	
	
	public String findFileName(Vector<Index> indexVector, int code) {
		for(int i=0; i<indexVector.size(); i++) {
			Index data = indexVector.get(i);
			if(data.checkCode(code)) return data.findFileName(code);
		}return null;
	}

	public void run(VUserInfo vUserInfo, Scanner keyboard) { 
			System.out.println(vUserInfo.getName()+"님 안녕하세요.");
			String campusFileName = nextIndex("캠퍼스 코드를 선택하세요.", "data/root.txt", keyboard);
			campusFileName = "data/" + campusFileName + ".txt";
			
			String collegeFileName = nextIndex("대학 코드를 선택하세요.", campusFileName , keyboard);
			collegeFileName = "data/" + collegeFileName + ".txt";
			
			String departmentFileName = nextIndex("학부 코드를 선택하세요.", collegeFileName , keyboard);
			departmentFileName = "data/" + departmentFileName + ".txt";
			
			printLectureList("강좌 목록", departmentFileName);
	}


}
